LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/addresses.csv'
INTO TABLE addresses 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/case_locations.csv'
INTO TABLE case_locations 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/departments.csv'
INTO TABLE departments 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/food_permit_licenses.csv'
INTO TABLE food_permit_licenses 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/food_permits.csv'
INTO TABLE food_permits 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/inspection_results.csv'
INTO TABLE inspection_results 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/inspection_violations.csv'
INTO TABLE inspection_violations
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/inspections.csv'
INTO TABLE inspections
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/isd_licenses.csv'
INTO TABLE isd_licenses 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/isd_locations.csv'
INTO TABLE isd_locations 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/lb_alcohol_types.csv'
INTO TABLE lb_alcohol_types 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/lb_license_managers.csv'
INTO TABLE lb_license_managers 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/lb_license_types.csv'
INTO TABLE lb_license_types 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/lb_licenses.csv'
INTO TABLE lb_licenses 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/michelin_awards.csv'
INTO TABLE michelin_awards
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/michelin_facilities.csv'
INTO TABLE michelin_facilities
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/michelin_restaurants.csv'
INTO TABLE michelin_restaurants 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/service_cases.csv'
INTO TABLE service_cases 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/service_types.csv'
INTO TABLE service_types 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/severity_levels.csv'
INTO TABLE severity_levels 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/teams.csv'
INTO TABLE teams 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/violation_types.csv'
INTO TABLE violation_types
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE '/Users/janet/Downloads/CS3200/cs3200-project/normalized/zip_codes.csv'
INTO TABLE zip_codes
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;
